/**********************************************************************
 * Copyright (c) 2021-2023
 *  Sang-Hoon Kim <sanghoonkim@ajou.ac.kr>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTIABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 **********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>

/* To avoid security error on Visual Studio */
#define _CRT_SECURE_NO_WARNINGS
#pragma warning(disable : 4996)

/*====================================================================*/
/*          ****** DO NOT MODIFY ANYTHING FROM THIS LINE ******       */
#define MAX_NR_TOKENS	16	/* Maximum length of tokens in a command */
#define MAX_TOKEN_LEN	32	/* Maximum length of single token */
#define MAX_ASSEMBLY	128 /* Maximum length of assembly string */

typedef unsigned char bool;
#define true	1
#define false	0
/*          ****** DO NOT MODIFY ANYTHING UP TO THIS LINE ******      */
/*====================================================================*/


/***********************************************************************
 * translate()
 *
 * DESCRIPTION
 *   Translate assembly represented in @tokens[] into a MIPS instruction.
 *   This translate should support following 13 assembly commands
 *
 *    - add
 *    - addi
 *    - sub
 *    - and
 *    - andi
 *    - or
 *    - ori
 *    - nor
 *    - lw
 *    - sw
 *    - sll
 *    - srl
 *    - sra
 *    - beq
 *    - bne
 *
 * RETURN VALUE
 *   Return a 32-bit MIPS instruction
 *
 */

int t_dump(char *dump)
{
    int t_out;
    if(dump[0] == 'v'){
        t_out = 2 + atoi(&dump[1]);
        return t_out;
    } else if(dump[0] == 'a'){
        t_out = 4 + atoi(&dump[1]);
        return t_out;
    } else if(dump[0] == 't'){
        if(atoi(&dump[1]) <= 7){
            t_out = 8 + atoi(&dump[1]);
            return t_out;
        } else{
            t_out = 16 + atoi(&dump[1]);
            return t_out;
        }
    } else if(dump[0] == 's'){
        t_out = 16 + atoi(&dump[1]);
        return t_out;
    } else if(dump[0] == 'k'){
        t_out = 25 + atoi(&dump[1]);
        return t_out;
    }
    return 0;
}

const char* find_rx(char rx[])
{
	if(!strcmp("zero", rx)){
		return "00000";
	} else if(!strcmp("at", rx)){
		return "00001";
	} else if(!strcmp("gp", rx)){
		return "11100";
	} else if(!strcmp("sp", rx)){
		return "11101";
	} else if(!strcmp("fp", rx)){
		return "11110";
	} else if(!strcmp("ra", rx)){
		return "11111";
	} else{
		int temp = t_dump(rx);
        static char vat[6] = {0};
        for(int i = 0; i < 5; i++)
        {
            if(temp == 0){
                vat[4 - i] = '0';
            }
            else if(temp % 2 == 1){
                vat[4 - i] = '1';
            } else{
                vat[4 - i] = '0';
            }
            temp = temp / 2;

        }
        return vat;
	}
}

const char* to_x(int n)
{
	static char x_temp[2] = {0};
    if(n < 10){
        x_temp[0] = '0' + n;
        x_temp[1] = '\0';
    } else{
        x_temp[0] = 'a' + (n - 10);
        x_temp[1] = '\0';
    }
    return x_temp;
}

char *r_format[5] = {"add", "sub", "and", "or", "nor"};
char *f_r_format[5] = {"100000", "100010", "100100", "100101", "100111"};
	
char *s_format[3] = {"sll", "srl", "sra"};
char *f_s_format[3] = {"000000", "000010", "000011"};
	
char *i_format[7] = {"addi", "andi", "ori", "lw", "sw", "beq", "bne"};
char *f_i_format[7] = {"001000", "001100", "001101", "100011", "101011", "000100", "000101"};


static unsigned int translate(int nr_tokens, char *tokens[])
{
	/* TODO:
	 * This is an example MIPS instruction. You should change it accordingly.
	 */

	char op[5];
	strcpy(op, tokens[0]);

	// type = 0(r_type), type = 1(s_type), type = 2(i_type)
	int format = 3;
	int format_index = 0;
	
	// find type
	for(int i = 0; i < 5; i++)
	{
		if(!strcmp(op, r_format[i])){
			format = 0;
			format_index = i;
			break;
		}
	}
	for(int i = 0; i < 3; i++)
	{
		if(!strcmp(op, s_format[i])){
			format = 1;
			format_index = i;
			break;
		}
	}
	for(int i = 0; i < 7; i++)
	{
		if(!strcmp(op, i_format[i])){
			format = 2;
			format_index = i;
			break;
		}
	}

	char word[33];
	char opcode[7] = {"000000"};
	char x_dump[8][5];
    char x_word[9];
	unsigned int result;
	char rs[6] = {0};
	char rt[6] = {0};
	char rd[6] = {0};
	int j;

	switch(format){
		case 0:
			strncat(word, opcode, 6);

			strcpy(rs, find_rx(tokens[2]));
			strncat(word, rs, 5);

			strcpy(rt, find_rx(tokens[3]));
			strncat(word, rt, 5);

			strcpy(rd, find_rx(tokens[1]));
			strncat(word, rd, 5);

			strncat(word, opcode, 5);

			strncat(word, f_r_format[format_index], 6);

			// printf("word: %s\n", word);

			j = 0;
			for(int i = 0; i < 8; i++)
			{
				strncpy(x_dump[i], word + j, 4);
				j += 4;
			}
			for(int i = 0; i < 8; i++)
			{
				strcat(x_word, to_x(strtol(x_dump[i], NULL, 2)));
		
			}

			result = strtol(x_word, NULL, 16);
			
			break;
		case 1:
			strncat(word, opcode, 6);

			strncat(word, opcode, 5);

			strcpy(rt, find_rx(tokens[2]));
			strncat(word, rt, 5);

			strcpy(rd, find_rx(tokens[1]));
			strncat(word, rd, 5);

			int sh;
			if(tokens[3][1] == 'x' || tokens[3][2] == 'x'){
				sh = strtol(tokens[3], NULL, 16);
			} else{
				sh = strtol(tokens[3], NULL, 10);
			}
			char sh_dump[6] = {0};
			for(int i = 0; i < 5; i++){
				if(sh == 0){
					sh_dump[4 - i] = '0';
				}
				else if(sh % 2 == 1){
					sh_dump[4 - i] = '1';
				} else{
					sh_dump[4 - i] = '0';
				}
				sh = sh / 2;
			}
			strncat(word, sh_dump, 5);

			strncat(word, f_s_format[format_index], 6);
			// printf("word : %s\n", word);

			j = 0;
			for(int i = 0; i < 8; i++)
			{
				strncpy(x_dump[i], word + j, 4);
				j += 4;
			}
			for(int i = 0; i < 8; i++)
			{
				strcat(x_word, to_x(strtol(x_dump[i], NULL, 2)));
		
			}

			result = strtol(x_word, NULL, 16);
			break;
		case 2:
			strncat(word, f_i_format[format_index], 6);

			char off_dump[17] = {0};
			if(format_index == 3 || format_index == 4){
				strcpy(rs, find_rx(tokens[3]));

				int offset;
				if(tokens[2][1] == 'x' || tokens[2][2] == 'x'){
					offset = strtol(tokens[2], NULL, 16);
				} else{
					offset = strtol(tokens[2], NULL, 10);
				}
				for(int i = 0; i < 16; i++){
					if(offset == 0){
						off_dump[15 - i] = '0';
					}
					else if(offset % 2 == 1){
						off_dump[15 - i] = '1';
					} else{
						off_dump[15 - i] = '0';
					}
					offset = offset / 2;
				}
			} else{
				strcpy(rs, find_rx(tokens[2]));

				int offset;
				if(tokens[3][1] == 'x' || tokens[3][2] == 'x'){
					offset = strtol(tokens[3], NULL, 16);
				} else{
					offset = strtol(tokens[3], NULL, 10);
				}
				for(int i = 0; i < 16; i++){
					if(offset == 0){
						off_dump[15 - i] = '0';
					}
					else if(offset % 2 == 1){
						off_dump[15 - i] = '1';
					} else{
						off_dump[15 - i] = '0';
					}
					offset = offset / 2;
				}

			}

			strcpy(rt, find_rx(tokens[1]));

			strncat(word, rs, 5);
			strncat(word, rt, 5);
			strncat(word, off_dump, 16);

			j = 0;
			for(int i = 0; i < 8; i++)
			{
				strncpy(x_dump[i], word + j, 4);
				j += 4;
			}
			for(int i = 0; i < 8; i++)
			{
				strcat(x_word, to_x(strtol(x_dump[i], NULL, 2)));
		
			}

			result = strtol(x_word, NULL, 16);
			break;
		default:
			result = 0x00000000;
			break;

	}

	

//0x02324020
	return result;
}



/***********************************************************************
 * parse_command()
 *
 * DESCRIPTION
 *   Parse @assembly, and put each assembly token into @tokens[] and the number
 *   of tokes into @nr_tokens. You may use this implemention or your own
 *   from PA0.
 *
 *   A assembly token is defined as a string without any whitespace (i.e., space
 *   and tab in this programming assignment). For exmaple,
 *     command = "  add t1   t2 s0 "
 *
 *   then, nr_tokens = 4, and tokens is
 *     tokens[0] = "add"
 *     tokens[1] = "t0"
 *     tokens[2] = "t1"
 *     tokens[3] = "s0"
 *
 *   You can assume that the characters in the input string are all lowercase
 *   for testing.
 *
 *
 * RETURN VALUE
 *   Return 0 after filling in @nr_tokens and @tokens[] properly
 *
 */
static int parse_command(char *assembly, int *nr_tokens, char *tokens[])
{
	char *curr = assembly;
	int token_started = false;
	*nr_tokens = 0;

	while (*curr != '\0') {  
		if (isspace(*curr)) {  
			*curr = '\0';
			token_started = false;
		} else {
			if (!token_started) {
				tokens[*nr_tokens] = curr;
				*nr_tokens += 1;
				token_started = true;
			}
		}
		curr++;
	}

	return 0;
}


/*====================================================================*/
/*          ****** DO NOT MODIFY ANYTHING BELOW THIS LINE ******      */

/***********************************************************************
 * The main function of this program.
 */
int main(int argc, char * const argv[])
{
	char assembly[MAX_ASSEMBLY] = { '\0' };
	FILE *input = stdin;

	if (argc > 1) {
		input = fopen(argv[1], "r");
		if (!input) {
			fprintf(stderr, "No input file %s\n", argv[0]);
			return EXIT_FAILURE;
		}
	}

	if (input == stdin) {
		printf("*********************************************************\n");
		printf("*          >> SCE212 MIPS translator  v0.10 <<          *\n");
		printf("*                                                       *\n");
		printf("*                                       .---.           *\n");
		printf("*                           .--------.  |___|           *\n");
		printf("*                           |.------.|  |=. |           *\n");
		printf("*                           || >>_  ||  |-- |           *\n");
		printf("*                           |'------'|  |   |           *\n");
		printf("*                           ')______('~~|___|           *\n");
		printf("*                                                       *\n");
		printf("*                                   Fall 2023           *\n");
		printf("*********************************************************\n\n");
		printf(">> ");
	}

	while (fgets(assembly, sizeof(assembly), input)) {
		char *tokens[MAX_NR_TOKENS] = { NULL };
		int nr_tokens = 0;
		unsigned int instruction;

		for (size_t i = 0; i < strlen(assembly); i++) {
			assembly[i] = tolower(assembly[i]);
		}

		if (parse_command(assembly, &nr_tokens, tokens) < 0)
			continue;

		instruction = translate(nr_tokens, tokens);

		fprintf(stderr, "0x%08x\n", instruction);

		if (input == stdin) printf(">> ");
	}

	if (input != stdin) fclose(input);

	return EXIT_SUCCESS;
}
