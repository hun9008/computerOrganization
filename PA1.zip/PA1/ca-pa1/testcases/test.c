#include <stdio.h>
#include <inttypes.h>
#include <stdlib.h>
#include <string.h>
#define true 1
#define false 0

int t_dump(char *dump)
{
    int t_out;
    if(dump[0] == 'v'){
        t_out = 2 + atoi(&dump[1]);
        return t_out;
    } else if(dump[0] == 'a'){
        t_out = 4 + atoi(&dump[1]);
        return t_out;
    } else if(dump[0] == 't'){
        if(atoi(&dump[1]) <= 7){
            t_out = 8 + atoi(&dump[1]);
            return t_out;
        } else{
            t_out = 16 + atoi(&dump[1]);
            return t_out;
        }
    } else if(dump[0] == 's'){
        t_out = 16 + atoi(&dump[1]);
        return t_out;
    } else if(dump[0] == 'k'){
        t_out = 25 + atoi(&dump[1]);
        return t_out;
    }
    return 0;
}

const char* find_rx(char rx[])
{
	if(!strcmp("zero", rx)){
		return "00000";
	} else if(!strcmp("at", rx)){
		return "00001";
	} else if(!strcmp("gp", rx)){
		return "11100";
	} else if(!strcmp("sp", rx)){
		return "11101";
	} else if(!strcmp("fp", rx)){
		return "11110";
	} else if(!strcmp("ra", rx)){
		return "11111";
	} else{
		int temp = t_dump(rx);
        static char vat[6];
        for(int i = 0; i < 5; i++)
        {
            if(temp == 0){
                vat[4 - i] = '0';
            }
            else if(temp % 2 == 1){
                vat[4 - i] = '1';
            } else{
                vat[4 - i] = '0';
            }
            temp = temp / 2;

        }
        return vat;
	}
}

const char* to_x(int n)
{
    static char temp[2];
    if(n < 10){
        temp[0] = '0' + n;
        temp[1] = '\0';
    } else{
        temp[0] = 'a' + (n - 10);
        temp[1] = '\0';
    }
    return temp;
}


int main(void){

    // char *hex = "00000001001000101001000000100010";
    // char *wei = "0110";
    
    // printf("%lx\n", strtol(hex, &hex+32, 10));
    // printf("%lx\n", strtol(wei, &wei+5, 16));
    // printf("%jx\n", strtoimax(wei, NULL, 16));

    // char *dump[26] = {"v0", "v1", "a0", "a1", "a2", "a3", "t0", "t1", "t2", "t3", "t4", "t5", "t6", "t7", "s0", "s1", "s2", "s3", "s4", "s5", "s6", "s7", "t8", "t9", "k1", "k2"};

    // for(int i = 0; i < 26; i++)
    // {
    //     // printf("%s\n", dump[i]);
    //     printf("%s\n", find_rx(dump[i]));
    // // }
    // char word[33];

    // char op[7] = {"000000"};
    // char rs[6] = {"11111"};
    // char rt[6] = {"22222"};

    // strncat(word, op, 6);
    // printf("%s\n", word);
    // strncat(word, rs, 5);
    // printf("%s\n", word);
    // strncat(word, rt, 5);
    // printf("%s\n", word);

    // char word[32] = "00000001001010100100000000100000";
    // char dump[5] = "0101";
    // char x_dump[8][5];
    // char x_word[9];

    // // strncat(x_dump[0], word + 4, 4);
    // // // strncat(test, word, 4);
    // // printf("%s\n", x_dump[0]);
    // int j = 0;
    // for(int i = 0; i < 8; i++)
    // {
    //     strncpy(x_dump[i], word + j, 4);
    //     printf("%s\n", x_dump[i]);
    //     j += 4;
    // }

    // for(int i = 0; i < 8; i++)
    // {
    //     printf("%s", to_x(strtol(x_dump[i], &x_dump[i]+4, 2)));
    //     strcat(x_word, to_x(strtol(x_dump[i], &x_dump[i]+4, 2)));
    // }

    // printf("\n%s\n", x_word);
    // int result = strtol(x_word, &x_word+8, 16);
    // printf("%x\n", result);
    // // printf("%d\n", strtol(x_dump[3], NULL, 2));
    // // printf("%s\n", to_x(13));

    char *temp = "0x10";

    printf("%d\n", strtol(temp, NULL, 16));




    return 0;
}