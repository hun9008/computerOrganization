#include <stdio.h>
#include <string.h>

int main(void){
    FILE *file = fopen("output.txt", "w");
    if (file == NULL) {
        printf("파일을 열 수 없습니다!\n");
        return 1;
    }

    char *r_format[5] = {"add ", "sub ", "and ", "or ", "nor "};
    char *res[32] = {"zero ", "at ", "v0 ", "v1 ", "a0 ", "a1 ", "a2 ", "a3 ", "t0 ", "t1 ", "t2 ", "t3 ", "t4 ", "t5 ", "t6 ", "t7 ","t8 ", "t9 ", "s0 ", "s1 ", "s2 ", "s3 ", "s4 ","s5 ", "s6 ","s7 "," k1 ", "k2 ","gp ","sp ","fp ","ra "  };
    
    char word[30];
    for(int i = 0; i < 5; i++)
    {
        for(int j = 0; j < 32; j++)
        {
            for(int k = 0; k < 32; k++)
            {
                for(int l = 0; l < 32; l++)
                {
                    strcat(word, r_format[i]);
                    strcat(word, res[j]);
                    strcat(word, res[k]);
                    strcat(word, res[l]);
                    fprintf(file, "%s\n", word);
                    strcpy(word, "");
                }
            }
        }
    }



    fprintf(file, "안녕하세요, 파일에 쓰기 예제입니다!\n");
    
    fclose(file);

    return 0;
}